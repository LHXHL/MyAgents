import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { deviceDisplayNameSchema, deviceNameMutationSchema, metadataSchemas } from '../src/index';

test('device nicknames are bounded single-line presentation text', () => {
  for (const name of ['家里 Windows', '办公室 Mac', '😀', 'x'.repeat(160)])
    assert.equal(deviceDisplayNameSchema.safeParse(name).success, true, name);
  for (const name of ['', ' ', ' Mac', 'Mac ', '\0', 'a\nb', 'a\tb', 'a\u0085b', 'a\u2028b', 'x'.repeat(161), '😀'.repeat(81)])
    assert.equal(deviceDisplayNameSchema.safeParse(name).success, false, JSON.stringify(name));
});

test('rename mutations and receipts have closed ID-based scopes', () => {
  const scope = { networkId: '11111111-1111-4111-8111-111111111111', principalId: 'account',
    deviceId: '22222222-2222-4222-8222-222222222222', name: '家里 Windows' };
  const mutation = { name: scope.name, expectedName: 'DESKTOP-123', mutationId: scope.deviceId };
  assert.equal(deviceNameMutationSchema.safeParse(mutation).success, true);
  assert.equal(deviceNameMutationSchema.safeParse({ ...mutation, deviceId: scope.deviceId }).success, false);
  assert.equal(metadataSchemas.deviceName.safeParse(scope).success, true);
  assert.equal(metadataSchemas.receipt.safeParse(scope).success, true);
  assert.equal(metadataSchemas.deviceName.safeParse({ ...scope, customName: 'private storage field' }).success, false);
});

test('device rename mutations agree with the shared Rust fixture set', async () => {
  const cases = JSON.parse(await readFile(new URL('../fixtures/device-names.json', import.meta.url), 'utf8'));
  for (const item of cases)
    assert.equal(deviceNameMutationSchema.safeParse(item.value).success, item.valid, item.name);
});
