import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { parseAgentReference, parseSessionReference, parseBusinessObject, clientControlSchema, serverControlSchema, accessClaimsSchema, catalogSchema } from '../src/index';

const fixture = JSON.parse(await readFile(new URL('../fixtures/parity.json', import.meta.url), 'utf8')) as {
  references: { kind: string; value: string; valid: boolean }[];
  business: { name: string; value: unknown; valid: boolean }[];
  controls: { name: string; value: unknown; valid: boolean }[];
  catalogs: { name: string; value: unknown; valid: boolean }[];
  access: { name: string; value: unknown; valid: boolean }[];
  serverControls: { name: string; value: unknown; valid: boolean }[];
};
test('TypeScript accepts exactly the cross-language fixture set', () => {
  for (const item of fixture.references) {
    const parse = () => item.kind === 'agent' ? parseAgentReference(item.value) : parseSessionReference(item.value);
    if (item.valid) assert.doesNotThrow(parse, item.value); else assert.throws(parse, item.value);
  }
  for (const item of fixture.business) {
    if (item.valid) assert.doesNotThrow(() => parseBusinessObject(item.value), item.name);
    else assert.throws(() => parseBusinessObject(item.value), item.name);
  }
  for (const [schema, cases] of [[clientControlSchema, fixture.controls], [catalogSchema, fixture.catalogs], [accessClaimsSchema, fixture.access], [serverControlSchema, fixture.serverControls]] as const)
    for (const item of cases) assert.equal(schema.safeParse(item.value).success, item.valid, item.name);
});
