import {z} from 'zod';
const uuid=z.string().regex(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/);
const httpsOrigin=z.string().max(2048).refine(value=>{try{const u=new URL(value);return u.protocol==='https:'&&u.origin===value&&!u.username&&!u.password;}catch{return false;}});
export const selfhostDescriptorSchema=z.object({serviceId:uuid,environment:z.enum(['production','development']),principalId:uuid,networkId:uuid,name:z.string().min(1).max(128),issuer:httpsOrigin,protocol:z.literal(1),capabilities:z.array(z.enum(['tls13-mtls','typed-rpc','permit-v1','return-v1'])).min(4).max(4),rootCertificate:z.string().min(1).max(20000),jwks:z.object({keys:z.array(z.object({kty:z.literal('EC'),crv:z.literal('P-256'),x:z.string(),y:z.string(),kid:z.string(),alg:z.literal('ES256'),use:z.literal('sig')}).strict()).min(1).max(8)}).strict()}).strict();
export type SelfhostDescriptor=z.infer<typeof selfhostDescriptorSchema>;
