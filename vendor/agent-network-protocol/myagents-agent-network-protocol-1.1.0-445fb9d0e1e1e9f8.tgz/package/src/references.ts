export const CANONICAL_UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
// Matches SessionStore's existing filename policy, including legacy IDs.
export const LOCAL_SESSION_ID = /^[a-zA-Z0-9-]{1,99}$/;

export class NetworkProtocolError extends Error {
  constructor(readonly code: string, message: string) {
    super(message);
    this.name = 'NetworkProtocolError';
  }
}

export interface AgentReference {
  serviceId: string;
  networkId: string;
  mountId: string;
}
export interface SessionReference extends AgentReference { localSessionId: string }

function uuid(value: string): string {
  if (!CANONICAL_UUID.test(value)) throw new NetworkProtocolError('INVALID_REFERENCE', 'A network reference requires canonical UUIDs.');
  return value;
}

export function agentReference(ref: AgentReference): string {
  return `ma-agent:1:${uuid(ref.serviceId)}:${uuid(ref.networkId)}:${uuid(ref.mountId)}`;
}

export function sessionReference(ref: SessionReference): string {
  if (!LOCAL_SESSION_ID.test(ref.localSessionId)) throw new NetworkProtocolError('INVALID_REFERENCE', 'Invalid local Session identity.');
  const token = btoa(ref.localSessionId).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  return `ma-session:1:${uuid(ref.serviceId)}:${uuid(ref.networkId)}:${uuid(ref.mountId)}:${token}`;
}

export function parseAgentReference(value: string): AgentReference {
  const parts = value.split(':');
  if (parts.length !== 5 || parts[0] !== 'ma-agent' || parts[1] !== '1') {
    throw new NetworkProtocolError('INVALID_REFERENCE', 'Unsupported or malformed Agent reference.');
  }
  return { serviceId: uuid(parts[2]), networkId: uuid(parts[3]), mountId: uuid(parts[4]) };
}

export function parseSessionReference(value: string): SessionReference {
  const parts = value.split(':');
  if (parts.length !== 6 || parts[0] !== 'ma-session' || parts[1] !== '1' || !/^[A-Za-z0-9_-]+$/.test(parts[5])) {
    throw new NetworkProtocolError('INVALID_REFERENCE', 'Unsupported or malformed Session reference.');
  }
  let localSessionId: string;
  try { localSessionId = atob(parts[5].replace(/-/g, '+').replace(/_/g, '/')); }
  catch { throw new NetworkProtocolError('INVALID_REFERENCE', 'Invalid Session reference encoding.'); }
  const ref = { serviceId: uuid(parts[2]), networkId: uuid(parts[3]), mountId: uuid(parts[4]), localSessionId };
  if (sessionReference(ref) !== value) throw new NetworkProtocolError('INVALID_REFERENCE', 'Noncanonical Session reference.');
  return ref;
}

/** Reserved namespaces must never silently fall back to a local lookup. */
export function isNetworkReference(value: string): boolean { return value.startsWith('ma-'); }
