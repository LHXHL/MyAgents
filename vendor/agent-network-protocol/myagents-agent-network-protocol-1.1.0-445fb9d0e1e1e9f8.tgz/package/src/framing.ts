import { NETWORK_BUDGETS } from './budgets';
import { CANONICAL_UUID, NetworkProtocolError } from './references';

export const TLS_FRAME_HEADER_BYTES = 22;

export function encodeTlsFrame(channelId: string, payload: Uint8Array): Uint8Array {
  if (!CANONICAL_UUID.test(channelId)) throw new NetworkProtocolError('INVALID_FRAME', 'Invalid channel identity.');
  if (!payload.length || payload.length > NETWORK_BUDGETS.tlsChunkBytes) throw new NetworkProtocolError('MESSAGE_TOO_LARGE', 'Invalid TLS chunk size.');
  const frame = new Uint8Array(TLS_FRAME_HEADER_BYTES + payload.length);
  frame[0] = 1; frame[1] = 1;
  const hex = channelId.replace(/-/g, '');
  for (let i = 0; i < 16; i++) frame[i + 2] = Number.parseInt(hex.slice(i * 2, i * 2 + 2), 16);
  new DataView(frame.buffer).setUint32(18, payload.length);
  frame.set(payload, TLS_FRAME_HEADER_BYTES);
  return frame;
}

export function decodeTlsFrame(frame: Uint8Array): { channelId: string; payload: Uint8Array } {
  if (frame.length <= TLS_FRAME_HEADER_BYTES || frame[0] !== 1 || frame[1] !== 1) throw new NetworkProtocolError('INVALID_FRAME', 'Unsupported TLS relay frame.');
  const len = new DataView(frame.buffer, frame.byteOffset, frame.byteLength).getUint32(18);
  if (!len || len > NETWORK_BUDGETS.tlsChunkBytes || len !== frame.length - TLS_FRAME_HEADER_BYTES) throw new NetworkProtocolError('INVALID_FRAME', 'TLS chunk length mismatch.');
  const hex = Array.from(frame.subarray(2, 18), value => value.toString(16).padStart(2, '0')).join('');
  const channelId = `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
  return { channelId, payload: frame.subarray(TLS_FRAME_HEADER_BYTES) };
}
