import test from 'node:test';
import assert from 'node:assert/strict';
import {
  agentReference, sessionReference, parseAgentReference, parseSessionReference,
  encodeTlsFrame, decodeTlsFrame, parseBusinessObject, catalogSchema,
  mountMutationSchema, NETWORK_BUDGETS,
} from '../src/index';

const ref = { serviceId: '11111111-1111-4111-8111-111111111111',
  networkId: '22222222-2222-4222-8222-222222222222', mountId: '33333333-3333-4333-8333-333333333333' };
const scope = { serviceId: ref.serviceId, environment: 'development', networkId: ref.networkId,
  principalId: 'account-a', deviceId: '44444444-4444-4444-8444-444444444444', keyGeneration: 1 };
const invocation = {
  version: 1, kind: 'invoke', senderSequence: 1,
  opId: '55555555-5555-4555-8555-555555555555', requestId: '66666666-6666-4666-8666-666666666666',
  source: scope, caller: { kind: 'external-cli', label: 'External CLI' },
  targetMountId: ref.mountId, method: 'session.start',
  params: { localAgentId: 'agent-legacy', prompt: 'hello', replyBack: false, messageId: '77777777-7777-4777-8777-777777777777' },
};

test('references round-trip legacy Session IDs and never accept noncanonical locators', () => {
  assert.deepEqual(parseAgentReference(agentReference(ref)), ref);
  for (const localSessionId of ['a', 'session-123-legacy', 'ABC-123', 'a'.repeat(99)]) {
    const session = { ...ref, localSessionId };
    assert.deepEqual(parseSessionReference(sessionReference(session)), session);
  }
  for (const bad of ['../etc/passwd', '', 'a'.repeat(100), 'a:b', '中文']) {
    assert.throws(() => sessionReference({ ...ref, localSessionId: bad }));
  }
  const encoded = sessionReference({ ...ref, localSessionId: 'a' });
  for (const bad of [encoded + '=', encoded.replace(/:1:/, ':2:'), encoded.replace(/:YQ$/, ':YR'),
    agentReference(ref).replace('4111', 'ABCD'), encoded.replace('ma-session', 'ma-agent')]) {
    assert.throws(() => parseSessionReference(bad));
  }
});

test('TLS frame boundaries survive a sliced buffer and reject corrupt lengths, versions and kinds', () => {
  const data = new Uint8Array([10, 20, 30]);
  const frame = encodeTlsFrame(ref.mountId, data);
  const padded = new Uint8Array(frame.length + 7); padded.set(frame, 5);
  assert.deepEqual(decodeTlsFrame(padded.subarray(5, 5 + frame.length)), { channelId: ref.mountId, payload: data });
  for (const offset of [0, 1, 21]) {
    const corrupt = frame.slice(); corrupt[offset] ^= 1;
    assert.throws(() => decodeTlsFrame(corrupt));
  }
  assert.throws(() => decodeTlsFrame(frame.subarray(0, frame.length - 1)));
  assert.throws(() => encodeTlsFrame(ref.mountId, new Uint8Array(NETWORK_BUDGETS.tlsChunkBytes + 1)));
});

test('business dispatch rejects arbitrary methods, paths, overrides and external return/watch capabilities', () => {
  assert.equal(parseBusinessObject(invocation).kind, 'invoke');
  for (const bad of [
    { ...invocation, method: 'config.write' },
    { ...invocation, workspacePath: '/private' },
    { ...invocation, params: { ...invocation.params, permissionMode: 'fullAgency' } },
    { ...invocation, params: { ...invocation.params, replyBack: true } },
    { ...invocation, returnRouteId: ref.mountId },
    { ...invocation, senderSequence: Number.MAX_SAFE_INTEGER + 1 },
    { ...invocation, method: 'session.watch', params: { localAgentId: 'a', localSessionId: 's', watchId: ref.mountId } },
  ]) assert.throws(() => parseBusinessObject(bad));
});

test('catalog facts cannot smuggle settings and each mutation expresses exactly one CAS intent', () => {
  const item = { localAgentId: 'a', localWorkspaceId: 'w', name: 'n', path: '/p', lifecycle: 'active', exposureRevision: 0 };
  const snapshot = { version: 1, connectionEpoch: scope.deviceId, catalogSeq: 1, items: [item] };
  assert.equal(catalogSchema.safeParse(snapshot).success, true);
  assert.equal(catalogSchema.safeParse({ ...snapshot, items: [{ ...item, enabled: true }] }).success, false);
  const mutation = { mutationId: ref.mountId, expectedMembershipRevision: 0, expectedEnableRevision: 0, enabled: true };
  assert.equal(mountMutationSchema.safeParse(mutation).success, true);
  assert.equal(mountMutationSchema.safeParse({ ...mutation, description: 'mixed write' }).success, false);
});
