import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { z } from 'zod';
import { NETWORK_BUDGETS, REMOTE_DEADLINES } from '../src/budgets';
import {
  businessObjectSchema, clientControlSchema, catalogSchema, peerBindingSchema,
  membershipMutationSchema, mountMutationSchema, serverControlSchema, accessClaimsSchema,
  signedPeerClaimsSchema, accountRosterSchema, bootstrapClaimsSchema, identityStateSchema, metadataSchemas,
  sourceRequestSchema, operationSchema,
} from '../src/contracts';

const dir = new URL('../schemas/', import.meta.url);
const schemas = { operation: operationSchema, sourceRequest: sourceRequestSchema, business: businessObjectSchema, clientControl: clientControlSchema,
  catalog: catalogSchema, peerBinding: peerBindingSchema,
  membershipMutation: membershipMutationSchema, mountMutation: mountMutationSchema,
  serverControl: serverControlSchema, accessClaims: accessClaimsSchema,
  signedPeerClaims: signedPeerClaimsSchema, accountRoster: accountRosterSchema,
  bootstrapClaims: bootstrapClaimsSchema, identityState: identityStateSchema,
  ...Object.fromEntries(Object.entries(metadataSchemas).map(([key, schema]) => [`metadata-${key}`, schema])) };
const files: Record<string, unknown> = Object.fromEntries(Object.entries(schemas).map(([name, schema]) =>
  [`${name}.json`, { ...z.toJSONSchema(schema), $id: `https://schemas.myagents.io/agent-network/v1/${name}` }],
));
files['budgets.json'] = { ...NETWORK_BUDGETS, remoteDeadlines: REMOTE_DEADLINES };
await mkdir(dir, { recursive: true });
for (const [name, value] of Object.entries(files)) {
  const expected = `${JSON.stringify(value, null, 2)}\n`;
  const path = new URL(name, dir);
  if (process.argv.includes('--check')) {
    if (await readFile(path, 'utf8') !== expected) throw new Error(`Protocol schema ${name} is stale. Run npm run schemas in the protocol package.`);
  } else await writeFile(path, expected);
}
