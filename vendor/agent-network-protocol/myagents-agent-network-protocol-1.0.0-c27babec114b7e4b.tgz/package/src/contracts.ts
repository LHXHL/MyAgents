import { z } from 'zod';
import { NETWORK_BUDGETS } from './budgets';
import { CANONICAL_UUID, LOCAL_SESSION_ID, NetworkProtocolError } from './references';

const uuid = z.string().regex(CANONICAL_UUID);
const id = z.string().min(1).max(256);
const sessionId = z.string().regex(LOCAL_SESSION_ID);
const revision = z.number().int().min(0).max(Number.MAX_SAFE_INTEGER);
const positive = revision.min(1);
const text = z.string().max(NETWORK_BUDGETS.objectBytes);
const nullableText = z.string().max(4096).nullable();
const environment = z.enum(['production', 'development']);
const runtime = z.enum(['builtin', 'dsh', 'claude-code', 'codex', 'gemini']);
const error = z.strictObject({ code: id, message: z.string().max(8192) });

export const deviceScopeSchema = z.strictObject({
  serviceId: uuid, environment, networkId: uuid, principalId: id,
  deviceId: uuid, keyGeneration: positive,
});

export const peerBindingSchema = z.strictObject({
  serviceId: uuid, environment, principalId: id, deviceId: uuid,
  keyGeneration: positive, identityBindingId: uuid,
  certificateFingerprint: z.string().regex(/^[A-Za-z0-9_-]{43}$/),
  san: z.string().max(253), certificate: z.string().max(16_384),
  expiresAt: positive,
});

export const callerSchema = z.discriminatedUnion('kind', [
  z.strictObject({ kind: z.literal('external-cli'), label: z.string().max(320) }),
  z.strictObject({ kind: z.literal('internal-session'), sourceSessionId: sessionId,
    sourceAgentId: id, label: z.string().max(320) }),
]);

const invokeBase = {
  version: z.literal(1), kind: z.literal('invoke'), opId: uuid, requestId: uuid,
  senderSequence: positive, source: deviceScopeSchema,
  caller: callerSchema, targetMountId: uuid, returnRouteId: uuid.optional(),
};
const agent = { localAgentId: id };
const session = { ...agent, localSessionId: sessionId };
const message = { prompt: text.min(1), messageId: uuid, replyBack: z.boolean() };

export const invocationSchema = z.discriminatedUnion('method', [
  z.strictObject({ ...invokeBase, method: z.literal('agent.show'), params: z.strictObject(agent) }),
  z.strictObject({ ...invokeBase, method: z.literal('session.list'),
    params: z.strictObject({ ...agent, limit: z.number().int().min(1).max(50) }) }),
  z.strictObject({ ...invokeBase, method: z.literal('session.get'),
    params: z.strictObject({ ...session, limit: z.number().int().min(1).max(500), before: id.optional() }) }),
  z.strictObject({ ...invokeBase, method: z.literal('session.start'), params: z.strictObject({ ...agent, ...message }) }),
  z.strictObject({ ...invokeBase, method: z.literal('session.send'), params: z.strictObject({ ...session, ...message }) }),
  z.strictObject({ ...invokeBase, method: z.literal('session.state'), params: z.strictObject(session) }),
  z.strictObject({ ...invokeBase, method: z.literal('session.watch'), params: z.strictObject({ ...session, watchId: uuid }) }),
]);
export const operationSchema = z.union(invocationSchema.options.map(schema => schema.pick({ method: true, params: true })));

// Source host supplies provenance separately. No target-local identity or
// execution override can be supplied through this addressing boundary.
export const sourceOperationSchema = z.discriminatedUnion('method', [
  z.strictObject({ method: z.literal('agent.show'), params: z.strictObject({}) }),
  z.strictObject({ method: z.literal('session.list'), params: z.strictObject({ limit: z.number().int().min(1).max(50) }) }),
  z.strictObject({ method: z.literal('session.get'), params: z.strictObject({ limit: z.number().int().min(1).max(500), before: id.optional() }) }),
  z.strictObject({ method: z.literal('session.start'), params: z.strictObject(message) }),
  z.strictObject({ method: z.literal('session.send'), params: z.strictObject(message) }),
  z.strictObject({ method: z.literal('session.state'), params: z.strictObject({}) }),
  z.strictObject({ method: z.literal('session.watch'), params: z.strictObject({ watchId: uuid }) }),
]);
export const sourceRequestSchema = z.strictObject({
  selector: z.string().min(1).max(512), requestId: uuid, operation: sourceOperationSchema,
});
export type SourceRequest = z.infer<typeof sourceRequestSchema>;

const showResult = z.strictObject({
  agentId: id, name: z.string().max(4096), enabled: z.boolean(), projectId: id.nullable(),
  archived: z.boolean(), archivedAt: nullableText,
  association: z.enum(['project-linked', 'legacy-project', 'legacy-orphan']),
  isCurrent: z.boolean(), channelCount: revision,
  effectiveDefaults: z.strictObject({
    runtime, runtimeSource: z.enum(['integrated', 'managed-provider', 'system-cli']).optional(),
    model: nullableText, permissionMode: nullableText, providerId: nullableText,
    mcpEnabledServers: z.array(id).max(5000), enabledPluginIds: z.array(id).max(5000),
    enabledOfficialToolIds: z.array(id).max(5000),
  }),
});
// Runtime config and paths are deliberately absent from the remote show DTO.
const sessionListItem = z.strictObject({
  sessionId, title: z.string().max(4096), lastActiveAt: z.string().max(128),
  lastMessagePreview: nullableText, runtime,
  runtimeSource: z.enum(['integrated', 'managed-provider', 'system-cli']).nullable(), model: nullableText,
  origin: z.union([
    z.strictObject({ kind: z.literal('registered-agent'), surface: z.literal('space_issue_delivery'),
      context: z.strictObject({ spaceId: id, registeredAgentId: id }) }),
    z.strictObject({ kind: z.enum(['desktop', 'automation', 'agent-channel', 'session-inbox', 'unknown']),
      surface: z.enum(['launcher_input', 'agent_card', 'new_chat_button', 'task_center', 'assistant',
        'agent_setup', 'floating_ball', 'session_fork', 'cmd_k', 'external_link', 'cron', 'task_run',
        'memory_update', 'channel_message', 'channel_heartbeat', 'session_send', 'session_reply', 'unknown']) }),
  ]).nullable(),
});
const sessionTextMessage = z.strictObject({
  id, role: z.enum(['user', 'assistant']), timestamp: z.string().max(128), content: text,
  turnId: id.optional(), transcriptState: z.enum(['streaming', 'complete', 'interrupted']).optional(),
});
const startResult = z.strictObject({
  accepted: z.boolean().nullable(), asynchronous: z.boolean().optional(),
  agentId: id.optional(), sessionId: sessionId.optional(), messageId: uuid.optional(),
  replyBack: z.boolean().optional(), resultDelivery: z.literal('send.result').optional(),
  unconfirmed: z.boolean().optional(), error: error.optional(),
});
const sendResult = z.strictObject({
  delivered: z.boolean(), unconfirmed: z.boolean().optional(), fromLabel: z.string().max(320).optional(),
  messageId: uuid.optional(), replyBack: z.boolean().optional(), error: error.optional(),
});
export const latestSessionResultSchema = z.strictObject({
  text: text.nullable(), source: z.enum(['live', 'history', 'none', 'unavailable']),
  scope: z.literal('latest-session-result'), timestamp: z.string().max(128).optional(),
  terminalStatus: z.enum(['complete', 'stopped', 'error']).optional(), turnId: id.optional(),
});
const watchResult = z.strictObject({
  watched: z.boolean(), watchId: uuid.optional(), targetSessionId: sessionId.optional(),
  targetStateAtRegistration: id.optional(), delivery: z.enum(['registered', 'already_idle', 'error']).optional(),
  eventPrompt: text.optional(), error: error.optional(),
  turnId: id.optional(), coalesced: z.boolean().optional(), latestResult: latestSessionResultSchema.optional(),
});
export const outcomeSchema = z.discriminatedUnion('method', [
  z.strictObject({ method: z.literal('agent.show'), result: showResult }),
  z.strictObject({ method: z.literal('session.list'), result: z.array(sessionListItem).max(50) }),
  z.strictObject({ method: z.literal('session.get'), result: z.strictObject({
    id: sessionId, messages: z.array(sessionTextMessage).max(500), hasMoreBefore: z.boolean(),
    isLive: z.boolean(), liveSessionState: z.string().max(128).nullable(), snapshotRevision: revision,
  }) }),
  z.strictObject({ method: z.literal('session.state'), result: z.strictObject({
    sessionId, state: z.enum(['idle', 'running', 'waiting_user']),
  }) }),
  z.strictObject({ method: z.literal('session.start'), result: startResult }),
  z.strictObject({ method: z.literal('session.send'), result: sendResult }),
  z.strictObject({ method: z.literal('session.watch'), result: watchResult }),
  z.strictObject({ method: z.literal('error'), error }),
]);

export const responseSchema = z.strictObject({
  version: z.literal(1), kind: z.literal('response'), opId: uuid, requestId: uuid,
  senderSequence: positive, outcome: outcomeSchema,
});
const eventBase = {
  version: z.literal(1), eventId: uuid, createdAt: z.string().max(128),
  sourceSessionId: sessionId, targetSessionId: sessionId,
  sourceKind: z.literal('internal-session').optional(), sourceLabel: z.string().max(320).optional(),
  targetLabel: z.string().max(320).optional(),
  turnId: id.optional(), terminalStatus: z.enum(['complete', 'stopped', 'error']).optional(),
  requestEventIds: z.array(uuid).max(NETWORK_BUDGETS.returns).optional(),
  watchIds: z.array(uuid).max(NETWORK_BUDGETS.watches).optional(),
  resultSource: z.enum(['live', 'history', 'none', 'unavailable']).optional(),
  resultScope: z.literal('latest-session-result').optional(),
};
export const returnSessionEventSchema = z.union([
  z.strictObject({ ...eventBase, type: z.literal('send.result'), requestEventId: uuid,
    status: z.enum(['ok', 'error']), terminalReason: id.optional(), errorCode: id.optional(), payload: text }),
  z.strictObject({ ...eventBase, type: z.enum(['watch.already_idle', 'watch.completed', 'watch.error']),
    watchId: uuid, targetStateAtRegistration: id, finalState: id.optional(), terminalReason: id.optional(), latestResult: text }),
]);
export const returnEventSchema = z.strictObject({
  version: z.literal(1), kind: z.literal('return-event'), opId: uuid,
  senderSequence: positive, returnRouteId: uuid, event: returnSessionEventSchema,
  source: deviceScopeSchema, target: deviceScopeSchema, targetLocalSessionId: sessionId,
});
export const returnAckSchema = z.strictObject({
  version: z.literal(1), kind: z.literal('return-ack'), opId: uuid,
  senderSequence: positive, returnRouteId: uuid, eventId: uuid,
  settlement: z.enum(['delivered', 'unconfirmed', 'dropped']),
});
export const channelHelloSchema = z.strictObject({
  version: z.literal(1), kind: z.literal('channel.hello'), senderSequence: positive,
  channelId: uuid, source: deviceScopeSchema, target: deviceScopeSchema,
  sourceConnectionEpoch: uuid, targetConnectionEpoch: uuid,
});
export const businessObjectSchema = z.union([
  invocationSchema, responseSchema, returnEventSchema, returnAckSchema, channelHelloSchema,
]);

export const catalogItemSchema = z.strictObject({
  localAgentId: id, localWorkspaceId: id, name: z.string().max(4096), path: z.string().max(16_384),
  lifecycle: z.enum(['active', 'archived', 'removed']), exposureRevision: revision,
});
export const catalogSchema = z.strictObject({
  version: z.literal(1), connectionEpoch: uuid, catalogSeq: positive,
  items: z.array(catalogItemSchema).max(NETWORK_BUDGETS.catalogItems),
});
export const membershipMutationSchema = z.strictObject({
  expectedMembershipRevision: revision, mutationId: uuid,
});
export const mountMutationSchema = z.union([
  z.strictObject({ enabled: z.boolean(), expectedEnableRevision: revision,
    expectedMembershipRevision: revision, mutationId: uuid }),
  z.strictObject({ description: z.string().max(NETWORK_BUDGETS.descriptionBytes).nullable(),
    expectedDescriptionRevision: revision, expectedMembershipRevision: revision, mutationId: uuid }),
]);

const controlBase = { version: z.literal(1), controlId: uuid };
const scopedControl = { ...controlBase, serviceId: uuid, networkId: uuid, bootEpoch: uuid, connectionEpoch: uuid };
const channel = { channelId: uuid };
export const clientControlSchema = z.discriminatedUnion('type', [
  z.strictObject({ ...controlBase, type: z.literal('hello'), clientVersion: id,
    capabilities: z.array(z.enum(['tls13-mtls', 'typed-rpc', 'permit-v1', 'return-v1'])).max(4),
    previousConnection: z.strictObject({ connectionEpoch: uuid, connectorNonce: uuid }).optional() }),
  z.strictObject({ ...scopedControl, type: z.literal('auth.refresh'), accessToken: z.string().max(16_384) }),
  z.strictObject({ ...scopedControl, type: z.literal('ready'), catalogSeq: positive }),
  z.strictObject({ ...scopedControl, ...channel, type: z.literal('channel.open'), targetDeviceId: uuid,
    targetKeyGeneration: positive, targetConnectionEpoch: uuid, targetBinding: z.string().max(32_768).nullable() }),
  z.strictObject({ ...scopedControl, ...channel, type: z.literal('channel.accept'), signedBinding: z.string().max(32_768) }),
  z.strictObject({ ...scopedControl, ...channel, type: z.literal('channel.ready') }),
  z.strictObject({ ...scopedControl, ...channel, type: z.literal('credit.release'), sequence: positive, receivedBytes: revision }),
  z.strictObject({ ...scopedControl, type: z.literal('route.rebind'), returnRouteId: uuid, channelId: uuid }),
  z.strictObject({ ...scopedControl, ...channel, type: z.literal('channel.close'), reason: id }),
  z.strictObject({ ...scopedControl, ...channel, type: z.literal('op.prepare'), opId: uuid, targetMountId: uuid }),
  z.strictObject({ ...scopedControl, type: z.literal('op.release'), opId: uuid }),
  z.strictObject({ ...scopedControl, type: z.literal('permit.acquire'), opId: uuid, attemptId: uuid,
    targetMountId: uuid, expectedMembershipRevision: revision, expectedEnableRevision: revision }),
  z.strictObject({ ...scopedControl, type: z.literal('route.close'), returnRouteId: uuid, reason: id }),
]);

export const serverControlSchema = z.discriminatedUnion('type', [
  z.strictObject({ ...scopedControl, type: z.literal('hello.result'), identity: deviceScopeSchema,
    networkRevision: revision, membershipRevision: revision, connectorNonce: uuid }),
  z.strictObject({ ...scopedControl, type: z.literal('auth.refreshed'), expiresAt: positive }),
  z.strictObject({ ...scopedControl, type: z.literal('ready.result'), catalogSeq: positive }),
  z.strictObject({ ...scopedControl, ...channel, type: z.literal('channel.offer'),
    initiator: deviceScopeSchema, responder: deviceScopeSchema,
    initiatorConnectionEpoch: uuid, responderConnectionEpoch: uuid,
    initiatorBinding: z.string().max(32_768).nullable(), responderBinding: z.string().max(32_768).nullable() }),
  z.strictObject({ ...scopedControl, ...channel, type: z.literal('channel.accepted'), initiatorBinding: z.string().max(32_768), responderBinding: z.string().max(32_768) }),
  z.strictObject({ ...scopedControl, ...channel, type: z.literal('channel.ready') }),
  z.strictObject({ ...scopedControl, ...channel, type: z.literal('credit.available'), sequence: positive, receivedBytes: revision }),
  z.strictObject({ ...scopedControl, ...channel, type: z.literal('channel.closed'), reason: id }),
  z.strictObject({ ...scopedControl, type: z.literal('op.prepared'), opId: uuid,
    targetMountId: uuid, target: deviceScopeSchema, targetConnectionEpoch: uuid }),
  z.strictObject({ ...scopedControl, type: z.literal('permit.result'), opId: uuid, attemptId: uuid,
    permitId: uuid, source: deviceScopeSchema, target: deviceScopeSchema,
    sourceConnectionEpoch: uuid, targetConnectionEpoch: uuid, targetMountId: uuid,
    membershipRevision: revision, enableRevision: revision, freshnessMs: positive,
    returnRouteId: uuid }),
  z.strictObject({ ...scopedControl, type: z.literal('route.closed'), returnRouteId: uuid, reason: id }),
  z.strictObject({ ...scopedControl, type: z.literal('route.rebound'), returnRouteId: uuid, channelId: uuid }),
  z.strictObject({ ...scopedControl, type: z.literal('route.opened'), returnRouteId: uuid, opId: uuid,
    source: deviceScopeSchema, target: deviceScopeSchema,
    sourceConnectionEpoch: uuid, targetConnectionEpoch: uuid, targetMountId: uuid }),
  z.strictObject({ ...scopedControl, type: z.literal('change.available'),
    scope: z.enum(['settings', 'catalog', 'presence', 'roster']), revision }),
  z.strictObject({ ...controlBase, type: z.literal('error'), code: id, retryable: z.boolean() }),
]);

export const accountRosterSchema = z.strictObject({
  revision: id, devices: z.array(z.strictObject({
    deviceId: uuid, name: z.string().max(4096), platform: id,
    osVersion: z.string().max(4096), appVersion: id, lastAccountSeenAt: id,
  })).max(10_000),
});

// Registered JOSE claims are validated by JOSE and scope-specific checks; these
// application claims are additionally closed, so an issuer/token substitution
// cannot introduce an alternate origin, key source or authentication audience.
export const accessClaimsSchema = z.strictObject({
  iss: z.string().url(), aud: uuid, sub: id, iat: positive, nbf: positive, exp: positive,
  jti: uuid, environment, deviceId: uuid, keyGeneration: positive, sessionHandle: uuid,
  cnf: z.strictObject({ jkt: z.string().regex(/^[A-Za-z0-9_-]{43}$/) }),
});

export const signedPeerClaimsSchema = z.strictObject({
  iss: z.string().url(), aud: z.literal('myagents-agent-peer'), sub: id,
  iat: positive, nbf: positive, exp: positive, jti: uuid, binding: peerBindingSchema,
});

export const bootstrapClaimsSchema = accessClaimsSchema.extend({
  networkUrl: z.string().url(), rootCertificate: z.string().max(20_000),
});
export const identityStateSchema = z.strictObject({
  serviceId: uuid, environment, deviceId: uuid,
  keyGeneration: positive.nullable(), keyFingerprint: z.string().regex(/^[A-Za-z0-9_-]{43}$/).nullable(),
});

export type DeviceScope = z.infer<typeof deviceScopeSchema>;
export type PeerBinding = z.infer<typeof peerBindingSchema>;
export type VerifiedCaller = z.infer<typeof callerSchema>;
export type Invocation = z.infer<typeof invocationSchema>;
export type MethodOutcome = z.infer<typeof outcomeSchema>;
export type BusinessObject = z.infer<typeof businessObjectSchema>;
export type ClientControl = z.infer<typeof clientControlSchema>;
export type ServerControl = z.infer<typeof serverControlSchema>;
export type AccessClaims = z.infer<typeof accessClaimsSchema>;
export type CatalogItem = z.infer<typeof catalogItemSchema>;
export type CatalogSnapshot = z.infer<typeof catalogSchema>;
export type MountMutation = z.infer<typeof mountMutationSchema>;
export type MembershipMutation = z.infer<typeof membershipMutationSchema>;

export function parseBusinessObject(input: unknown): BusinessObject {
  const result = businessObjectSchema.safeParse(input);
  if (!result.success) throw new NetworkProtocolError('PROTOCOL_INVALID', 'Invalid encrypted business object.');
  const object = result.data;
  if (object.kind === 'invoke' && object.caller.kind === 'external-cli') {
    if (object.returnRouteId || object.method === 'session.watch'
      || ('replyBack' in object.params && object.params.replyBack)) {
      throw new NetworkProtocolError('EXTERNAL_CLI_CAPABILITY_NOT_OPEN', 'External CLI calls are one-way and cannot watch.');
    }
  }
  return object;
}

// Management projections are metadata only. Keep their response boundary as
// closed as the collaboration protocol, including nullable unsynced counts.
const membership = z.strictObject({ networkId: uuid, principalId: id, deviceId: uuid,
  joined: z.boolean(), membershipRevision: revision });
const mount = z.strictObject({ mountId: uuid, networkId: uuid, principalId: id, deviceId: uuid,
  localAgentId: id, enabled: z.boolean(), enableRevision: revision,
  description: nullableText, descriptionRevision: revision });
const managedAgent = z.strictObject({ ...mount.shape, localWorkspaceId: id,
  name: z.string().max(4096), path: z.string().max(16_384),
  lifecycle: z.literal('active'), catalogRevision: revision });
const managedDevice = z.strictObject({ ...membership.shape, name: z.string().max(4096),
  platform: z.string().max(256), osVersion: z.string().max(256), appVersion: z.string().max(128),
  lastAccountSeenAt: z.string().max(128), lastNetworkSeenAt: revision.nullable(), rosterRevision: z.string().max(256),
  catalogEpoch: uuid.nullable(), catalogSeq: revision, catalogSyncedAt: revision.nullable(),
  connectionState: z.enum(['ready', 'syncing', 'offline']), onlineAgentCount: revision.nullable() });
export const callableAgentSchema = z.strictObject({ mountId: uuid, localAgentId: id, name: z.string().max(4096),
  description: nullableText, deviceId: uuid, deviceName: z.string().max(4096), platform: z.string().max(256),
  membershipRevision: revision, enableRevision: revision, selector: z.string().max(256),
  isLocal: z.literal(false), source: z.strictObject({ serviceId: uuid, networkId: uuid }),
  connectionEpoch: uuid, keyGeneration: positive, signedBinding: z.string().max(32768).nullable() });
const page = <T extends z.ZodType>(item: T) => z.strictObject({ items: z.array(item).max(NETWORK_BUDGETS.pageMax),
  nextCursor: uuid.nullable(), complete: z.boolean() });
export const metadataSchemas = {
  network: z.strictObject({ serviceId: uuid, environment, networkId: uuid, principalId: id,
    name: z.string().max(4096), revision, protocol: z.literal(1), capabilities: z.array(z.string().max(128)).max(32) }),
  devices: page(managedDevice), agents: page(managedAgent), callable: page(callableAgentSchema),
  callableAgent: callableAgentSchema,
  membership, mount, catalog: z.strictObject({ connectionEpoch: uuid, catalogSeq: positive }),
  receipt: z.union([membership, mount]),
};
