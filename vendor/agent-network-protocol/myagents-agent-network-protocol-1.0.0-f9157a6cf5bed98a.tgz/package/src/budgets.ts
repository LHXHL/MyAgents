// Wire authority. Rust reads the checked-in JSON generated from these values.
export const NETWORK_BUDGETS = Object.freeze({
  controlBytes: 65_536, tlsChunkBytes: 65_536, objectBytes: 16 * 1024 * 1024,
  receiveBytes: 20 * 1024 * 1024, connectorBytes: 128 * 1024 * 1024,
  dedupBytes: 8 * 1024 * 1024, socketQueueBytes: 2 * 1024 * 1024,
  channelQueueBytes: 256 * 1024, relayQueueBytes: 8 * 1024 * 1024,
  relayMetadataBytes: 4 * 1024 * 1024, descriptionBytes: 4096,
  catalogItems: 5000, catalogBytes: 8 * 1024 * 1024,
  channels: 16, handshakes: 4, pending: 64, returns: 256, watches: 128,
  permits: 32, receipts: 1024, receiptMs: 600_000,
  pingMs: 15_000, offlineMs: 45_000, helloMs: 10_000,
  handshakeMs: 20_000, idleChannelMs: 300_000, backpressureMs: 30_000,
  permitMs: 5000, permitAttempts: 3, mutationMs: 86_400_000,
  tokenSeconds: 30 * 86_400, tokenRefreshSeconds: 0, certificateSeconds: 7 * 86_400,
  certificateRenewSeconds: 48 * 3600, popSeconds: 60, recoverySeconds: 600,
  clockSkewSeconds: 30, pageSize: 50, pageMax: 200,
});

// Nested source budgets include handshake + target admission, never terminal.
export const REMOTE_DEADLINES = Object.freeze({
  'agent.show': { cli: 35_000, admin: 30_000, connector: 25_000 },
  'session.list': { cli: 35_000, admin: 30_000, connector: 25_000 },
  'session.get': { cli: 35_000, admin: 30_000, connector: 25_000 },
  'session.start': { cli: 225_000, admin: 220_000, connector: 210_000 },
  'session.send': { cli: 70_000, admin: 65_000, connector: 55_000 },
  'session.watch': { cli: 70_000, admin: 65_000, connector: 55_000 },
});

export const NETWORK_VERSION = 1 as const;
export const NETWORK_SUBPROTOCOL = 'myagents-agent-network.v1';
export const NETWORK_ALPN = 'myagents-agent/1';
